﻿using Domain;
using ReadModel.Asset;

namespace ReadModel
{
    public abstract class EventHandler<T> where T: Event
    {
        //protected IMessageBus MessageBus { get; }
        protected IAssetRepository AssetRepository { get; }

        protected EventHandler(IAssetRepository assetRepository)
        {
            //MessageBus = messageBus;
            AssetRepository = assetRepository;
            //MessageBus.Subscribe<T>(Handle);
        }

        public abstract void Handle(T ev);
    }
}