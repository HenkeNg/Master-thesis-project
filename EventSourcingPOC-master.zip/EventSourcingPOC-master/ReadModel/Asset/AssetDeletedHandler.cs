using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetDeletedHandler : EventHandler<AssetDeleted>
    {
        public AssetDeletedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetDeleted ev)
        {
            var x = new Dictionary<string,string>();
            if (ev.Deleted)
            {
                x["deleted"] = "true";
            }
            else
            {
                x["deleted"] = "false";
            }

            AssetRepository.UpdateAsset(x,ev.AggregateId, ev.Id);
        }
    }
}