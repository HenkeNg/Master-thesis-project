using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetLanguageUpdateHandler
    {
        public class AssetLanguageUpdatedHandler : EventHandler<AssetLanguageUpdated>
        {
            public AssetLanguageUpdatedHandler(IAssetRepository assetRepository) : base(assetRepository)
            {
            }

            public override void Handle(AssetLanguageUpdated ev)
            {
                var x = new Dictionary<string, string> {["language"] = ev.Language};
                AssetRepository.UpdateAsset(x, ev.AggregateId,ev.Id);
            }
        }
    }
}