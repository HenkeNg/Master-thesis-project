using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetModifiedByUpdatedHandler : EventHandler<AssetModifiedByUpdated>
    {
        public AssetModifiedByUpdatedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetModifiedByUpdated ev)
        {
            var x = new Dictionary<string, string> {["modifiedby"] = ev.ModifiedBy.ToString()};
            AssetRepository.UpdateAsset( x, ev.AggregateId ,ev.Id);
        }
    }
}