using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
        public class AssetMainTitleUpdateHandler : EventHandler<AssetMainTitleUpdated>
        {
            public AssetMainTitleUpdateHandler(IAssetRepository assetRepository) : base(assetRepository)
            {
            }

            public override void Handle(AssetMainTitleUpdated ev)
            {          
                //var x = new Dictionary<string, string> {["mainTitle"] = ev.MainTitle};
               // AssetRepository.UpdateAsset( x, ev.AggregateId,ev.Id);
            }
        }
    
}