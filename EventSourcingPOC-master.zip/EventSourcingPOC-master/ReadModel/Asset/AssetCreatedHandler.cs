﻿using Domain.Entities.Asset;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetCreatedHandler : EventHandler<AssetCreated>
    {
        public AssetCreatedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetCreated ev)
        {
            AssetRepository.AddAsset(new AssetDto { Id = ev.AggregateId }, ev.Id);
        }
    }
}