﻿using System;
using System.Collections.Generic;
using Domain.Entities.Asset;

namespace ReadModel.Asset
{
    public interface IAssetRepository
    {
        long GetEventsCount();
        void AddAsset(AssetDto asset, Guid eventId);
        void UpdateAsset(Dictionary<string,string> dictionary,Guid aggregateId ,Guid eventId);
        IEnumerable<AssetDto> GetAssets();
        AssetDto GetAsset(Guid id);
        void DeleteAsset(Guid id, Guid eventId);
    }
}