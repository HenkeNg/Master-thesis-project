using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetSubtitleUpdateHandler : EventHandler<AssetSubtitleUpdated>
    {
        public AssetSubtitleUpdateHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetSubtitleUpdated ev)
        {          
            //var x = new Dictionary<string, string> {["subtitle"] = ev.Subtitle};
           // AssetRepository.UpdateAsset( x, ev.AggregateId,ev.Id);
        }
    }
}