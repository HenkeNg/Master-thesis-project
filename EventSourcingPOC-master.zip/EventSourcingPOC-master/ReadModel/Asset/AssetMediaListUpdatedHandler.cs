using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetMediaListUpdatedHandler : EventHandler<AssetMediaListUpdated>
    {
        public AssetMediaListUpdatedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetMediaListUpdated ev)
        {
            var x = new Dictionary<string, string> {["mediaList"] = ev.MediaList.ToString()};
            AssetRepository.UpdateAsset( x, ev.AggregateId ,ev.Id);
        }
    }
}