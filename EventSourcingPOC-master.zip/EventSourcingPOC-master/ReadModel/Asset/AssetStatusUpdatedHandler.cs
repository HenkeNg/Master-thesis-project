using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetStatusUpdatedHandler : EventHandler<AssetStatusUpdated>
    {
        public AssetStatusUpdatedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetStatusUpdated ev)
        {
            var x = new Dictionary<string, string> {["status"] = ev.Status};
            AssetRepository.UpdateAsset( x, ev.AggregateId ,ev.Id);
        }
    }
}