using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetCreatedByUpdatedHandler : EventHandler<AssetCreatedByUpdated>
    {
        public AssetCreatedByUpdatedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetCreatedByUpdated ev)
        {
            var x = new Dictionary<string, string> {["createdby"] = ev.CreatedBy.ToString()};
            AssetRepository.UpdateAsset(x,ev.AggregateId ,ev.Id);
        }
    }
}