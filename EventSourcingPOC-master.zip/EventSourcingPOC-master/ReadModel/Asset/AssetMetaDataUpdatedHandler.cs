using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetMetaDataUpdatedHandler : EventHandler<AssetMetaDataUpdated>
    {
        public AssetMetaDataUpdatedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetMetaDataUpdated ev)
        {
            var x = new Dictionary<string, string> {["metadata"] = ev.Metadata.ToString()};
            AssetRepository.UpdateAsset( x, ev.AggregateId ,ev.Id);
        }
    }
}