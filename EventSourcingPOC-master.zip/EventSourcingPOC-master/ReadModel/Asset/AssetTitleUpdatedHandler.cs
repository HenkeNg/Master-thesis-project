﻿using System.Collections.Generic;
using Domain.Entities.Asset.Events;

namespace ReadModel.Asset
{
    public class AssetTitleUpdatedHandler : EventHandler<AssetTitleUpdated>
    {
        public AssetTitleUpdatedHandler(IAssetRepository assetRepository) : base(assetRepository)
        {
        }

        public override void Handle(AssetTitleUpdated ev)
        {          
            var x = new Dictionary<string, string> {["title"] = ev.Title};
            AssetRepository.UpdateAsset( x, ev.AggregateId,ev.Id);
        }
    }
}