using System;
using System.Collections.Generic;
using Domain;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Infrastructure.converters
{
    public abstract class EventConverter
    {
        private class MockEvent : Event
        {
            public MockEvent(Guid causationId, Guid correlationId, Guid aggregateId): base(causationId, correlationId, aggregateId)
            {
            }
        }
        
        protected EventBase GetBaseEventJson(JObject eventJson, string eventType, string eventVersion)
        {
            
            var ev = new MockEvent(Guid.Parse(eventJson["CausationId"].ToString()), Guid.Parse(eventJson["CorrelationId"].ToString()), Guid.Parse(eventJson["AggregateId"].ToString()));
            ev.Type = eventType;
            ev.Version = eventVersion;
            return new EventBase(JObject.Parse(JsonConvert.SerializeObject(ev)),ev);
        }
                

        public abstract ConverterEvent Convert(string eventJson, Dictionary<string,Event> dictionary);
    }
}