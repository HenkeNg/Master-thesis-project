namespace Infrastructure.converters
{
    public class ConverterAttribute: System.Attribute
    {
        public string EventType { get; }
        public string EventVersion { get; }

        public ConverterAttribute(string eventType, string eventVersion)
        {
            EventType = eventType;
            EventVersion = eventVersion;
        }
    }
}