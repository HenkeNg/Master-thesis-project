using System.Collections.Generic;
using Domain;
using Newtonsoft.Json.Linq;

namespace Infrastructure.converters
{
    public class ConverterEvent
    {
        public IEnumerable<JObject> JObjects { get; }
        public Dictionary<string,Event> LatestDictionary { get; }

        public ConverterEvent(IEnumerable<JObject> jObjects, Dictionary<string, Event> dictionary)
        {
            JObjects = jObjects;
            LatestDictionary = dictionary;
        }
    }
}