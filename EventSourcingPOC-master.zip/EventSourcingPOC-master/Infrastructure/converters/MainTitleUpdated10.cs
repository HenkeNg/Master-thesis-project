using System;
using System.Collections.Generic;
using Domain;
using Domain.Entities.Asset.Events;
using Newtonsoft.Json.Linq;

namespace Infrastructure.converters
{
    [ConverterAttribute("Domain.Entities.Asset.Events.AssetMainTitleUpdated", "1.0")]
    public class MainTitleUpdated10: EventConverter
    {
        public override ConverterEvent Convert(string eventJson, Dictionary<string,Event> dictionary)
        {
            AssetSubtitleUpdated subTitleEvent = null;
            
            if(dictionary.ContainsKey("Subtitle"))
            {
                subTitleEvent = (AssetSubtitleUpdated) dictionary["Subtitle"];
            }
            
            var eventJobject = JObject.Parse(eventJson);
            var titleUpdatedBase = GetBaseEventJson(eventJobject,
                "Domain.Entities.Asset.Events.AssetTitleUpdated, Domain", "1.1");
            var titleUpdatedJobject = titleUpdatedBase.BaseEventObj;
            var mockEvent = titleUpdatedBase.BaseEvent;
            var titleUpdatedEvent = new AssetTitleUpdated(mockEvent.CausationId,mockEvent.CorrelationId, mockEvent.AggregateId,
               " "); 
            
            dictionary["MainTitle"] = new AssetMainTitleUpdated(mockEvent.CausationId,
                mockEvent.CorrelationId,mockEvent.AggregateId, eventJobject["MainTitle"].ToString());
           
         
            if (subTitleEvent != null)
            {
                titleUpdatedJobject.Add("Title", eventJobject["MainTitle"]+ " " + subTitleEvent.Subtitle);
                titleUpdatedEvent.Title = eventJobject["MainTitle"]+ " " + subTitleEvent.Subtitle;
            }
            else
            {
                titleUpdatedJobject.Add("Title", eventJobject["MainTitle"]);
                titleUpdatedEvent.Title = eventJobject["MainTitle"].ToString();
            }

            titleUpdatedEvent.Version = "1.1";
            dictionary["Title"] = titleUpdatedEvent;
            Console.WriteLine(titleUpdatedJobject);
            var listOfObj = new List<JObject>() {titleUpdatedJobject};
            return new ConverterEvent(listOfObj, dictionary);
        }
    }
}