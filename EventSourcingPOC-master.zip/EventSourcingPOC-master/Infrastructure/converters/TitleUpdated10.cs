using System;
using System.Collections.Generic;
using Domain;
using Domain.Entities.Asset.Events;
using Newtonsoft.Json.Linq;

namespace Infrastructure.converters
{
    [ConverterAttribute("Domain.Entities.Asset.Events.AssetTitleUpdated", "1.0")]
    public class TitleUpdated10: EventConverter
    {
        public override ConverterEvent Convert(string eventJson, Dictionary<string,Event> dictionary)
        {
            var eventJobject = JObject.Parse(eventJson);
     
            var titleParts = eventJobject["Title"].ToString().Split(" ");

            var title = titleParts[0];
            var subtitle = "";
            if (titleParts.Length > 1)
            {
                subtitle = titleParts[1];                
            }
                        
            var mainTitleUpdatedBase = GetBaseEventJson(eventJobject, "Domain.Entities.Asset.Events.AssetMainTitleUpdated, Domain", "1.0");
            var mainTitleUpdatedJobject = mainTitleUpdatedBase.BaseEventObj;
            mainTitleUpdatedJobject.Add("MainTitle", title);
            var mockevent = mainTitleUpdatedBase.BaseEvent;
            dictionary["Title"] = new AssetTitleUpdated(mockevent.CausationId,mockevent.CorrelationId,mockevent.AggregateId,eventJobject["Title"].ToString());
            var mainTitleUpdatedEvent = new AssetMainTitleUpdated(mockevent.CausationId,mockevent.CorrelationId,mockevent.AggregateId,title);
            mainTitleUpdatedEvent.Version = "1.0";
            dictionary["MainTitle"] = mainTitleUpdatedEvent;
    
            var subtitleUpdatedBase = GetBaseEventJson(eventJobject, "Domain.Entities.Asset.Events.AssetSubtitleUpdated, Domain", "1.0");
            var subtitleUpdatedJobject = subtitleUpdatedBase.BaseEventObj;
            subtitleUpdatedJobject.Add("Subtitle", subtitle);
            var subtitleUpdatedEvent = new AssetSubtitleUpdated(mockevent.CausationId, mockevent.CorrelationId,
                mockevent.AggregateId, subtitle);
           subtitleUpdatedEvent.Version = "1.0";
            dictionary["Subtitle"] = subtitleUpdatedEvent;

             var listOfObj = new List<JObject>()
            {
                mainTitleUpdatedJobject,
                subtitleUpdatedJobject
            };
             
             return new ConverterEvent(listOfObj,dictionary);
        }
    }
}