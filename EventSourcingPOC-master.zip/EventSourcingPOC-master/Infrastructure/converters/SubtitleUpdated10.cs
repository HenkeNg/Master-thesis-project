using System;
using System.Collections.Generic;
using Domain;
using Domain.Entities.Asset.Events;
using Newtonsoft.Json.Linq;

namespace Infrastructure.converters
{
    [Converter("Domain.Entities.Asset.Events.AssetSubtitleUpdated", "1.0")]
    public class SubtitleUpdated10 : EventConverter
    {
        public override ConverterEvent Convert(string eventJson, Dictionary<string, Event> dictionary)
        {
            AssetMainTitleUpdated mainTitleEvent = null;
            if(dictionary.ContainsKey("MainTitle"))
            {
               mainTitleEvent = (AssetMainTitleUpdated) dictionary["MainTitle"]; 
            }

            var eventJobject = JObject.Parse(eventJson);
            var titleUpdatedBase = GetBaseEventJson(eventJobject,
                "Domain.Entities.Asset.Events.AssetTitleUpdated, Domain", "1.1");
            var titleUpdatedJobject = titleUpdatedBase.BaseEventObj;
            var mockEvent = titleUpdatedBase.BaseEvent;
            var titleUpdatedEvent = new AssetTitleUpdated(mockEvent.CausationId,mockEvent.CorrelationId, mockEvent.AggregateId,
               " "); 

            dictionary["Subtitle"] = new AssetSubtitleUpdated(titleUpdatedEvent.CausationId,
                titleUpdatedEvent.CorrelationId,titleUpdatedEvent.AggregateId, eventJobject["Subtitle"].ToString());
           
         
            if (mainTitleEvent != null)
            {
                titleUpdatedJobject.Add("Title", mainTitleEvent.MainTitle + " " + eventJobject["Subtitle"]);
                titleUpdatedEvent.Title = mainTitleEvent.MainTitle + " " + eventJobject["Subtitle"];
            }
            else
            {
                titleUpdatedJobject.Add("Title", eventJobject["Subtitle"]);
                titleUpdatedEvent.Title = eventJobject["Subtitle"].ToString();
            }

            titleUpdatedEvent.Version = "1.1";
            dictionary["Title"] = titleUpdatedEvent;
            var listOfObj = new List<JObject>() {titleUpdatedJobject};
            return new ConverterEvent(listOfObj, dictionary);
        }
    }
}