using Domain;
using Newtonsoft.Json.Linq;

namespace Infrastructure.converters
{
    public class EventBase
    {
        public JObject BaseEventObj { get; }
        public Event BaseEvent { get; }

        public EventBase(JObject baseEventObj, Event baseEvent)
        {
            BaseEventObj = baseEventObj;
            BaseEvent = baseEvent;
        }
    }
}