﻿using System;
using System.Collections.Generic;
using System.Linq;
using Application;
using Domain;

namespace Infrastructure
{
    public class CommandService : ICommandService
    {
        private readonly Dictionary<Type, object> _commandHandler;

        public CommandService(IServiceProvider serviceProvider)
        {
            _commandHandler = new Dictionary<Type, object>();
            var handlerTypes = new List<Type>();

            var handlersAssembly = AppDomain.CurrentDomain.GetAssemblies()
                .FirstOrDefault(a => a.FullName.Contains("Application"));
            if (handlersAssembly == null)
            {
                throw new Exception("Missing command handlers assembly");
            }

            foreach (var type in handlersAssembly.GetTypes())
            {
                if (type.AssignableFromGenericAncestor(typeof(ICommandHandler<,>)) && !type.IsAbstract)
                {
                    handlerTypes.Add(type);
                }
            }

            foreach (var handlerType in handlerTypes)
            {
                _commandHandler[handlerType.GetAncestorGenericArguments()[0]] = Activator.CreateInstance(handlerType,
                    serviceProvider.GetService(typeof(IEventStore)), serviceProvider.GetService(typeof(IMessageBus)));
            }
        }

        public void ExecuteCommand(ICommand command, Guid? aggregateId = null)
        {
            if (_commandHandler.ContainsKey(command.GetType()))
            {
                dynamic handler = _commandHandler[command.GetType()];
                handler.Execute((dynamic) command, aggregateId);
            }
            else
            {
                throw new Exception(string.Format("Failed to find command handler for dommand '%s'", command.GetType().AssemblyQualifiedName));
            }
        }
    }
}