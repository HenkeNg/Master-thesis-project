﻿using System;
using System.Collections.Generic;
using System.Text;
using Application;
using Domain;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace Infrastructure
{
    public class RabbitMQMessageBus : IMessageBus
    {
        private IModel _connectionModel;
        private string _exchangeName = "EventSourcingExchange";
        private string _queueName = "EventSourcing";
        private string _routingKey = "key";

        public RabbitMQMessageBus()
        {
            Console.WriteLine("Connecting to RabbitMQ at host " + Environment.GetEnvironmentVariable("RABBITMQ_HOSTNAME"));
            var factory = new ConnectionFactory { HostName = Environment.GetEnvironmentVariable("RABBITMQ_HOSTNAME"), UserName = "guest", Password = "guest", AutomaticRecoveryEnabled = true };
            var connection = factory.CreateConnection();
            _connectionModel = connection.CreateModel();
            
            _connectionModel.ExchangeDeclare(_exchangeName, ExchangeType.Direct);
        }

        public void Publish(IMessage message)
        {
            var messageJson = JsonConvert.SerializeObject(message);
            var properties = _connectionModel.CreateBasicProperties();
            properties.ContentType = "application/json";
            properties.DeliveryMode = 2; //persistent
            properties.Headers = new Dictionary<string, object> {{"MessageType", message.GetType().AssemblyQualifiedName}};

            _connectionModel.BasicPublish(_exchangeName, message.GetType().ToString(), properties, Encoding.UTF8.GetBytes(messageJson));
        }

        public void Subscribe<T>(Action<T> handler) where T : class, IMessage
        {
            _connectionModel.QueueDeclare(typeof(T).ToString(), false, false, false);
            _connectionModel.QueueBind(typeof(T).ToString(), _exchangeName, typeof(T).ToString(), null);
            
            var consumer = new EventingBasicConsumer(_connectionModel);
            consumer.Received += (model, ea) =>
            {
                var body = ea.Body;
                var type = Type.GetType(Encoding.UTF8.GetString((byte[])ea.BasicProperties.Headers["MessageType"]));
                dynamic message = JsonConvert.DeserializeObject(Encoding.UTF8.GetString(body), type);
                handler(message);
                _connectionModel.BasicAck(ea.DeliveryTag, false);
            };
            _connectionModel.BasicConsume(typeof(T).ToString(), false, consumer);
        }
    }
}