﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure
{
    public static class TypeExtensions
    {
        public static bool AssignableFromGenericAncestor(this Type type, Type genericAncestorType)
        {
            if (type.IsGenericType && type.GetGenericTypeDefinition() == genericAncestorType)
            {
                return true;
            }

            var interfaces = type.GetInterfaces();

            if (interfaces.Any(iface => iface.IsGenericType && iface.GetGenericTypeDefinition() == genericAncestorType))
            {
                return true;
            }

            var baseType = type.BaseType;
            return baseType != null && baseType.AssignableFromGenericAncestor(genericAncestorType);
        }

        public static IList<Type> GetAncestorGenericArguments(this Type type)
        {
            if (type.IsGenericType)
            {
                return type.GetGenericArguments();
            }

            var genericInterface = type.GetInterfaces().FirstOrDefault(i => i.IsGenericType);

            if (genericInterface != null)
            {
                return genericInterface.GetGenericArguments();
            }

            var baseType = type.BaseType;
            return baseType == null ? new List<Type>() : baseType.GetAncestorGenericArguments();
        }
    }
}