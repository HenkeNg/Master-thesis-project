﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Application;
using Domain;
using EventStore.ClientAPI;
using EventStore.ClientAPI.Common.Log;
using EventStore.ClientAPI.Projections;
using EventStore.ClientAPI.SystemData;
using Infrastructure.converters;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Infrastructure
{
    public class EventStore : IEventStore
    {
        private readonly IEventStoreConnection _connection;
        private const string StreamName = "$ce-EventSourcingPOC";
        private static int _snapshotEventSize = 4000;

        public EventStore()
        {
            var connectionString = "ConnectTo=tcp://admin:changeit@" +
                                   Environment.GetEnvironmentVariable("EVENTSTORE_HOSTNAME") +
                                   ":1113; HeartBeatTimeout=500";
            _connection = EventStoreConnection.Create(connectionString);
            _connection.ConnectAsync().Wait();

            var projectionManager = new ProjectionsManager(new ConsoleLogger(),
                new DnsEndPoint(Environment.GetEnvironmentVariable("EVENTSTORE_HOSTNAME") ?? throw new SystemException("Missing Eventstore hostname environment variable"), 2113),
                TimeSpan.FromMilliseconds(5000));
            projectionManager.EnableAsync("$by_category", new UserCredentials("admin", "changeit")).Wait();

            var snapshotSetting = Environment.GetEnvironmentVariable("SNAPSHOT_EVENT_SIZE"); 
            if (!string.IsNullOrEmpty(snapshotSetting))
            {
                _snapshotEventSize = int.Parse(snapshotSetting);
            }
        }

        public async Task AppendToStreamAsync(Guid aggregateId, long expectedVersion, long expectedSnapshotVersion,
            IEnumerable<Event> events, Snapshot snapShot)
        {
            var eventsData = events.Select(@event => new EventData(@event.Id, @event.Type,
                    true, Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(@event)), Encoding.ASCII.GetBytes("{'Version': '" + @event.Version+ "'}")))
                .ToList();

            if (expectedVersion <= 0)
            {
                expectedVersion = ExpectedVersion.NoStream;
            }
                   
            await _connection.AppendToStreamAsync("EventSourcingPOC-" + aggregateId, expectedVersion, eventsData);
            if (expectedVersion - expectedSnapshotVersion >= _snapshotEventSize)
            {
                AttemptSnapShot(aggregateId, expectedSnapshotVersion, snapShot, expectedVersion+events.Count());
            }
        }

        private IEnumerable<JObject> GetUpdatedEvents(string eventJson, string eventType, string eventVersion,
                     Dictionary<string,Event> dictionary)
                 {
                     var events = new List<JObject>();
         
                     var converterType = GetType().Assembly.GetTypes().SingleOrDefault(t =>
                     {
                         var converterAttribute = t.GetCustomAttribute<ConverterAttribute>();
                         if (converterAttribute == null) return false;
                         
                         return converterAttribute.EventType == eventType.Split(",")[0].Trim() && converterAttribute.EventVersion == eventVersion;
                     });
         
                     if (converterType == null)
                     {
                         events.Add(JObject.Parse(eventJson));
                     }
                     else
                     {
                         var converter = (EventConverter) Activator.CreateInstance(converterType);
                         var convertedEvents = converter.Convert(eventJson,dictionary);
                         dictionary = convertedEvents.LatestDictionary;
                         var updatedEvents = convertedEvents.JObjects;
                         foreach (var updatedEvent in updatedEvents)
                         {
                             events.AddRange(GetUpdatedEvents(updatedEvent.ToString(), updatedEvent["Type"].ToString(), updatedEvent["Version"].ToString(),dictionary));  
                         }
                     }
                     
                     return events;
                 }
        
        
        private IEnumerable<Event> ConvertEvents(ResolvedEvent[] eventStoreEvents)
        {
            var result = new List<Event>();
            var dictionary = new Dictionary<string,Event>();
            foreach (var resolvedEvent in eventStoreEvents)
            {
                var metadata = JObject.Parse(Encoding.UTF8.GetString(resolvedEvent.Event.Metadata));
                var eventType = resolvedEvent.Event.EventType;
                var eventVersion = metadata["Version"].ToString().Trim();
                var eventPayload = Encoding.UTF8.GetString(resolvedEvent.Event.Data);
                
                var updatedEvents = GetUpdatedEvents(eventPayload, eventType, eventVersion,dictionary);
      
                foreach (var updatedEvent in updatedEvents)
                {
                    dynamic ev = JsonConvert.DeserializeObject(updatedEvent.ToString(),
                        Type.GetType(updatedEvent["Type"].ToString()));
                    ((Event) ev).Version = updatedEvent["Version"].ToString();
                    result.Add(ev);
                }
            }

            return result;
        }
        
        public async Task<EventStoreEvents> ReadAggregateEvents(Guid aggregateId)
        {
            var snapshot = await ReadLatestSnapShot(aggregateId);
            var events = new List<Event>();
            long startPosition = 0;
            long version = -1;

            if (snapshot != null)
            {
                events.Add(snapshot);
                startPosition = snapshot.AggregateVersion + 1;
                version = snapshot.AggregateVersion;
            }

            var nr = 4096;
            while (nr == 4096)
            {
                var eventsSlice =
                    await _connection.ReadStreamEventsForwardAsync("EventSourcingPOC-" + aggregateId, startPosition,
                        4096, true);
                version += eventsSlice.Events.Length;
                events.AddRange(ConvertEvents(eventsSlice.Events));
                nr = eventsSlice.Events.Length;
                startPosition += 4096;
            }

            return new EventStoreEvents(version, events);
        }

        public async Task<IEnumerable<Event>> ReadAllEvents(long startingPoint, int number)
        {
            var eventsSlice = await _connection.ReadStreamEventsForwardAsync(StreamName, startingPoint, number, true);
            return ConvertEvents(eventsSlice.Events);
        }        

        private void AttemptSnapShot(Guid aggregateId, long expectedSnapshotVersion, Snapshot newSnapShot, long version)
        {
            newSnapShot.MyVersion = expectedSnapshotVersion + 1;
            newSnapShot.AggregateVersion = version;
            var eventsData = new EventData(aggregateId, newSnapShot.GetType().AssemblyQualifiedName, true,
                Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(newSnapShot)), null);
            _connection.AppendToStreamAsync("EventSourcingPOCSnapShot-" + aggregateId, expectedSnapshotVersion,
                eventsData);
        }

        private async Task<Snapshot> ReadLatestSnapShot(Guid aggregateId)
        {
            var eventsSlice = await _connection.ReadStreamEventsBackwardAsync("EventSourcingPOCSnapShot-" + aggregateId,
                StreamPosition.End, 1, true);
            if (eventsSlice.Events.Length == 0)
            {
                return null;
            }
            
            return (Snapshot)JsonConvert.DeserializeObject(Encoding.UTF8.GetString(eventsSlice.Events.First().Event.Data),
                typeof(Snapshot));
        }
    }
}