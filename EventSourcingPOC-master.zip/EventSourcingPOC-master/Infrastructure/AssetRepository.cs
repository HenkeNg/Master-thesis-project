﻿using System;
using System.Collections.Generic;
using Domain.Entities.Asset;
using Npgsql;
using ReadModel.Asset;

namespace Infrastructure
{
    public class AssetRepository : IAssetRepository
    {
        private static readonly string PostgresHostname = Environment.GetEnvironmentVariable("POSTGRES_HOSTNAME");
        private static readonly string PostgresDatabase = Environment.GetEnvironmentVariable("POSTGRES_DATABASE");

        private readonly string _connString =
            "Host=" + PostgresHostname + ";Username=admin;Password=admin;Database=" + PostgresDatabase;

        public AssetRepository()
        {
            using (var conn = new NpgsqlConnection(_connString))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "CREATE TABLE IF NOT EXISTS assets(" + "id VARCHAR(80) PRIMARY KEY," +
                                      " title VARCHAR(255)," + " status VARCHAR(80)," + " language VARCHAR(80)," +
                                      " metadata VARCHAR(80)," + " mediaList VARCHAR(80)," + " createdBy VARCHAR(80)," +
                                      " modifiedBy VARCHAR(80)," + " deleted VARCHAR(10)" + ")";
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "CREATE TABLE IF NOT EXISTS assets_events(" + "id VARCHAR(80) PRIMARY KEY)";
                    cmd.ExecuteNonQuery();
                }

                conn.Close();
            }
        }

        public long GetEventsCount()
        {
            using (var conn = new NpgsqlConnection(_connString))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand("SELECT COUNT(*) as count FROM assets_events", conn))
                {
                    var count = cmd.ExecuteScalar();
                    if (count != null)
                    {
                        return (long) count;
                    }
                }

                conn.Close();
            }

            return 0;
        }

        private void LogEventId(Guid eventId, NpgsqlConnection connection, NpgsqlTransaction transaction)
        {
            using (var cmd = new NpgsqlCommand())
            {
                cmd.Transaction = transaction;

                cmd.Connection = connection;
                cmd.CommandText = "INSERT INTO assets_events(id) " + "VALUES ('" + eventId + "')";
                cmd.ExecuteNonQuery();
            }
        }

        public void AddAsset(AssetDto asset, Guid eventId)
        {
            using (var conn = new NpgsqlConnection(_connString))
            {
                conn.Open();
                var transaction = conn.BeginTransaction();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Transaction = transaction;

                    cmd.Connection = conn;
                    cmd.CommandText = "INSERT INTO assets(id, title) " + "VALUES ('" + asset.Id + "', '" + asset.Title +
                                      "')";
                    cmd.ExecuteNonQuery();
                }

                LogEventId(eventId, conn, transaction);

                transaction.Commit();
                conn.Close();
            }
        }

        public void UpdateAsset(Dictionary<string, string> dictionary, Guid aggregateId, Guid eventId)
        {
            using (var conn = new NpgsqlConnection(_connString))
            {
                conn.Open();
                var transaction = conn.BeginTransaction();

                using (var cmd = new NpgsqlCommand())
                {
                    foreach (var key in dictionary.Keys)
                    {
                        cmd.Connection = conn;
                        cmd.CommandText = "UPDATE assets " + "SET \"" + key + "\"='" + dictionary[key] + "' " +
                                          "WHERE " + "\"id\"='" + aggregateId + "'";
                        cmd.Transaction = transaction;
                        cmd.ExecuteNonQuery();
                    }
                }

                LogEventId(eventId, conn, transaction);
                transaction.Commit();
                conn.Close();
            }
        }

        public IEnumerable<AssetDto> GetAssets()
        {
            var result = new List<AssetDto>();
            using (var conn = new NpgsqlConnection(_connString))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand("SELECT * FROM assets", conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var assetDto = new AssetDto
                        {
                            Id = Guid.Parse((string) reader["id"]),
                            Title = (string) reader["title"],
                            Status = (string) reader["status"],
                            Language = (string) reader["language"],
                            CreatedBy = Guid.Parse((string) reader["createdBy"]),
                            ModifiedBy = Guid.Parse((string) reader["modifiedBy"]),
                            MetaData = Guid.Parse((string) reader["metadata"]),
                            MediaList = new List<Guid?>(), // todo FIX MEDIALIST
                            Deleted = false //(bool) reader["deleted"]
                        };

                        result.Add(assetDto);
                    }
                }

                conn.Close();
            }

            return result;
        }

        public AssetDto GetAsset(Guid id)
        {
            using (var conn = new NpgsqlConnection(_connString))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand("SELECT * FROM assets WHERE id='" + id + "'", conn))
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        var assetDto = new AssetDto
                        {
                            Id = Guid.Parse((string) reader["id"]),
                            Title = (string) reader["title"],
                            Status = (string) reader["status"],
                            Language = (string) reader["language"],
                            CreatedBy = Guid.Parse((string) reader["createdBy"]),
                            ModifiedBy = Guid.Parse((string) reader["modifiedBy"]),
                            MetaData = Guid.Parse((string) reader["metadata"]),
                            MediaList = new List<Guid?>(), // todo FIX MEDIALIST
                            Deleted = false //(bool) reader["deleted"]
                        };

                        return assetDto;
                    }
                }

                conn.Close();
            }

            return null;
        }

        public void DeleteAsset(Guid id, Guid eventId)
        {
            using (var conn = new NpgsqlConnection(_connString))
            {
                conn.Open();

                var transaction = conn.BeginTransaction();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "DELETE FROM assets " + "WHERE " + "id='" + id + "'";
                    cmd.ExecuteNonQuery();
                }

                LogEventId(eventId, conn, transaction);
                transaction.Commit();

                conn.Close();
            }
        }
    }
}