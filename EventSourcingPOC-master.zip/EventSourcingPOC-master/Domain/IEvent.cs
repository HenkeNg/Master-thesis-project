﻿using System;

namespace Domain
{
    public interface IEvent : IMessage
    {
        Guid AggregateId { get; set; }
    }
}