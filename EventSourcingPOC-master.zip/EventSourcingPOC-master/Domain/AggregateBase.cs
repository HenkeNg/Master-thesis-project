using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;

namespace Domain
{
    public abstract class AggregateBase
    {
        public List<Event> Changes { get; }
        public Dictionary<string,string> MediaList { get;}
        public long Version { get; set; }
        public long SnapshotVersion { get; set; }
        public long OldVersion { get; set; }
        public Guid Id { get; set; }

        protected AggregateBase()
        {
            Changes = new List<Event>();

            Version = -1;
            SnapshotVersion = -1;
        }

        public void RebuildState(IEnumerable<Event> events)
        {
            foreach (var @event in events)
            {
                if (!(@event is Snapshot))
                {
                    var applyMethod = GetType().GetMethod("Apply", BindingFlags.Instance | BindingFlags.NonPublic,
                        Type.DefaultBinder, new Type[] {@event.GetType()}, null);
                    if (applyMethod != null)
                    {
                        applyMethod.Invoke(this, new object[] {@event});
                    }
                }
                else
                {
                    ApplySnapshot(@event as Snapshot);
                }
            }
        }

        public Snapshot AssetSnapShot()
        {
            var stateDictionary = new Dictionary<string, string>();
            var aggregateProperties = GetType().GetProperties();

            foreach (var aggregateProperty in aggregateProperties)
            {
                if (aggregateProperty.Name.Equals("AddMedia") || aggregateProperty.Name.Equals("RemoveMedia") ||
                    aggregateProperties.Equals("MediaList"))
                {
                    
                }else if (aggregateProperty.GetValue(this) != null && aggregateProperty.Name != "Changes")
                {
                    if (aggregateProperty.PropertyType == typeof(string) ||
                        aggregateProperty.PropertyType == typeof(Guid))
                    {
                        stateDictionary[aggregateProperty.Name] = aggregateProperty.GetValue(this).ToString();
                    }
                    else if (aggregateProperty.PropertyType == typeof(object))
                    {
                        stateDictionary[aggregateProperty.Name] =
                            JsonConvert.SerializeObject(aggregateProperty.GetValue(this));
                    }
                    else
                    {
                        stateDictionary[aggregateProperty.Name] = aggregateProperty.GetValue(this).ToString();
                    }
                }
            }

            if (MediaList.Count >= 1)
            {
                StringBuilder sb = new StringBuilder();
                foreach (var key in MediaList.Keys)
                {
                    sb.Append(MediaList[key] + ",");
                }

                stateDictionary["MediaList"] = sb.ToString();
            }

            return new Snapshot(Id, JsonConvert.SerializeObject(stateDictionary, Formatting.Indented), OldVersion);
        }

        private void ApplySnapshot(Snapshot ev)
        {
            var stateMap = JsonConvert.DeserializeObject<Dictionary<string, string>>(ev.StateMap);

            foreach (var aggregateProperty in GetType().GetProperties())
            {
                if (!stateMap.ContainsKey(aggregateProperty.Name)) continue;

                if (aggregateProperty.PropertyType == typeof(string))
                {
                    if (aggregateProperty.Name.Equals("MediaList"))
                    {
                        String[] temp = stateMap[aggregateProperty.Name].Split(",");
                        foreach (var media in temp)
                        {
                            MediaList.Add(media,media);
                        }
                    }
                    else
                    {
                        aggregateProperty.SetValue(this, stateMap[aggregateProperty.Name], null);
                    }
                }
                else if (aggregateProperty.PropertyType == typeof(Guid))
                {
                    aggregateProperty.SetValue(this, Guid.Parse(stateMap[aggregateProperty.Name]), null);
                }
                else if (aggregateProperty.PropertyType == typeof(object))
                {
                    aggregateProperty.SetValue(this,
                        JsonConvert.DeserializeObject(stateMap[aggregateProperty.Name], aggregateProperty.PropertyType),
                        null);
                }
                else
                {
                    aggregateProperty.SetValue(this,
                        Convert.ChangeType(stateMap[aggregateProperty.Name], aggregateProperty.PropertyType), null);
                }
            }

            OldVersion = ev.AggregateVersion;
            SnapshotVersion = ev.MyVersion;
        }
    }
}