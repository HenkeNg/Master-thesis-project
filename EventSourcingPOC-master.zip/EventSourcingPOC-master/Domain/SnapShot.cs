using System;

namespace Domain
{
    public class Snapshot : Event
    {
        /// <summary>
        /// Json representation of the aggregate state
        /// </summary>
        public string StateMap { get; set; }
        
        public long AggregateVersion { get; set; }
        
        public long MyVersion { get; set; }
        
        [Obsolete("Serialization use only", true)]
        public Snapshot(){}

        public Snapshot(Guid aggregateId, string stateMap,long aggregateVersion)
        :base(Guid.Empty, Guid.Empty, aggregateId)
        {
            StateMap = stateMap;
            AggregateVersion = aggregateVersion;
        }
    }
}