﻿using System;

namespace Domain
{
    public interface ICommandHandler<in TC, in TA> where TC : ICommand where TA : AggregateBase
    {
        void Execute(TC command, Guid? aggregateId);
    }
}