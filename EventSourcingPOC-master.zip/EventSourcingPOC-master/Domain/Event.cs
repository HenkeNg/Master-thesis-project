﻿using System;

namespace Domain
{
    public abstract class Event : IEvent
    {
        public Guid Id { get; set; }
        public Guid CausationId { get; set; }
        public Guid CorrelationId { get; set; }
        public Guid AggregateId { get; set; }
        public string Type { get; set; }
        public string Version { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public Event()
        {
        }

        public Event(Guid causationId, Guid correlationId, Guid aggregateId)
        {
            Id = Guid.NewGuid();
            CausationId = causationId;
            CorrelationId = correlationId;
            AggregateId = aggregateId;
            Type = GetType().FullName + ", " + GetType().Assembly.GetName().Name;
            Version = "1.0";
        }
    }
}