﻿using System;
using System.Collections.Generic;

namespace Domain.Entities.Asset
{
    [Serializable]
    public class AssetDto
    {
        public string Title { get; set; }
        
        public string MainTitle { get; set; }
        
        public string Subtitle { get; set; }
        public string Status { get; set; }
        public string Language { get; set; }
        public Nullable<Guid> MetaData { get; set; }
        public Nullable<Guid> CreatedBy { get; set; }
        public Nullable<Guid> ModifiedBy { get; set; }
        public List<Nullable<Guid>> MediaList { get; set; }
        public bool Deleted { get; set; }

        public Guid? Id { get; set; }
    }
}