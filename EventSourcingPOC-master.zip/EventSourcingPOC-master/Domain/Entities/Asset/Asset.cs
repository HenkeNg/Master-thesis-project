﻿using System;
using System.Collections.Generic;
using Domain.Entities.Asset.Events;
using Domain.Entities.Asset.SharedMethods;

namespace Domain.Entities.Asset
{
    public class Asset : AggregateBase, IAggregate
    {
        private const string DefaultGuid = "00000000-0000-0000-0000-000000000000";
        private ObjectToDictionary _objectToDictionary;

        #region properties               

        private string _title;

        public string Title
        {
            get => _title;
            set
            {
                var oldValue = _title;
                if (value == null && _title == null)
                {
                    return;
                }

                if (_title == value)
                {
                    return;
                }

                _title = value;
                Changes.Add(new AssetTitleUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }
        
        private string _mainTitle;

        public string MainTitle
        {
            get => _mainTitle;
            set
            {
                var oldValue = _mainTitle;
                if (value == null && _mainTitle == null)
                {
                    return;
                }

                if (_mainTitle  == value)
                {
                    return;
                }

                _mainTitle  = value;
                Changes.Add(new AssetMainTitleUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }
        
        private string _subtitle;

        public string Subtitle
        {
            get => _subtitle;
            set
            {
                var oldValue = _subtitle;
                if (value == null && _subtitle == null)
                {
                    return;
                }

                if (_subtitle == value)
                {
                    return;
                }

                _subtitle = value;
                Changes.Add(new AssetSubtitleUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }

        private string _status;

        public string Status
        {
            get => _status;
            set
            {
                var oldValue = _status;
                if (value == null && _status == null)
                {
                    return;
                }

                if (_status == value)
                {
                    return;
                }

                _status = value;
                Changes.Add(new AssetStatusUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }

        public string _addMedia;

        public string AddMedia
        {
            get => _addMedia;
            set
            {
                _addMedia = value; 
                
                Changes.Add(new AssetMediaAddedUpdated(Guid.Empty,Guid.Empty,Id,value));
                MediaList.Add(_addMedia,_addMedia);
            }
        }
        public string _removeMedia;

        public string RemoveMedia
        {
            get => _removeMedia;
            set
            {
                _removeMedia = value; 
                
                Changes.Add(new AssetMediaAddedUpdated(Guid.Empty,Guid.Empty,Id,value));
                if (MediaList.ContainsKey(_removeMedia))
                {
                    MediaList.Remove(_removeMedia);
                }
            }
        }

        private string _language;

        public string Language
        {
            get => _language;
            set
            {
                var oldValue = _language;
                if (value == null && _language == null)
                {
                    return;
                }

                if (_language == value)
                {
                    return;
                }

                _language = value;

                Changes.Add(new AssetLanguageUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }

        private Nullable<Guid> _metaData;

        public Nullable<Guid> MetaData
        {
            get => _metaData;
            set
            {
                if (value.ToString() == DefaultGuid && _metaData.ToString() == DefaultGuid)
                {
                    return;
                }

                _metaData = value;
                Changes.Add(new AssetMetaDataUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }

        private Guid _createdBy;

        public Guid CreatedBy
        {
            get => _createdBy;
            set
            {
                if (value.ToString() == DefaultGuid && _createdBy.ToString() == DefaultGuid)
                {
                    return;
                }

                _createdBy = value;
                Changes.Add(new AssetCreatedByUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }

        private Guid _modifiedBy;

        public Guid ModifiedBy
        {
            get => _modifiedBy;
            set
            {
                if (value.ToString() == DefaultGuid && _modifiedBy.ToString() == DefaultGuid)
                {
                    return;
                }

                Changes.Add(new AssetModifiedByUpdated(Guid.Empty, Guid.Empty, Id, value));
            }
        }

        private bool _deleted;

        public bool Deleted
        {
            get { return _deleted; }
            set
            {
                _deleted = value;
                Changes.Add(new AssetDeleted(Guid.Empty, Guid.Empty, Id, value));
            }
        }
        
        #endregion

        public Asset() { }
        
        public Asset(Guid assetId)
        {
            if (assetId == null)
            {
                throw new Exception("Missing asset id");
            }

            Id = assetId;
            Changes.Add(new AssetCreated(Guid.Empty, Guid.Empty, Id));
        }


        public void UpdateAsset(object jsonObj)
        {
            _objectToDictionary = new ObjectToDictionary();
            var assetParameterUpdates = _objectToDictionary.TransformObject(jsonObj);

            foreach (var key in assetParameterUpdates.Keys)
            {
                if (key.Equals("Title"))
                {
                    Title = assetParameterUpdates[key];
                }
                else  if (key.Equals("MainTitle"))
                {
                    MainTitle = assetParameterUpdates[key];
                }
                else  if (key.Equals("Subtitle"))
                {
                    Subtitle = assetParameterUpdates[key];
                }
                else if (key.Equals("Status"))
                {
                    Status = assetParameterUpdates[key];
                }
                else if (key.Equals("Language"))
                {
                    Language = assetParameterUpdates[key];
                }
                else if (key.Equals("Metadata"))
                {
                    if (assetParameterUpdates[key] == null)
                    {
                        MetaData = null;
                    }
                    else
                    {
                        MetaData = new Guid(assetParameterUpdates[key]);
                    }
                }
                else if (key.Equals("MediaAdded"))
                {
                    AddMedia = assetParameterUpdates[key];
                }
                else if (key.Equals("MediaRemoved"))
                {
                    RemoveMedia = assetParameterUpdates[key];
                }
                // todo createdBy should be like asset/aggregateId, readonly, and set once
                else if (key.Equals("CreatedBy"))
                {
                    if (assetParameterUpdates[key] == null)
                    {
                        throw new Exception("Null exception for CreatedBy in UpdateAsset");
                    }

                    CreatedBy = new Guid(assetParameterUpdates[key]);
                }
                else if (key.Equals("ModifiedBy"))
                {
                    if (assetParameterUpdates[key] == null)
                    {
                        throw new Exception("Null exception for modifiedBy in UpdateAsset");
                    }

                    ModifiedBy = new Guid(assetParameterUpdates[key]);
                }
                else if (key.Equals("Deleted"))
                {
                    if (assetParameterUpdates[key].Equals("true"))
                    {
                        Deleted = true;
                    }
                    else
                    {
                        Deleted = false;
                    }
                }
            }
        }        

        private void Apply(AssetCreated ev)
        {
            Id = ev.AggregateId;
        }

        private void Apply(AssetTitleUpdated ev)
        {
            _title = ev.Title;
        }

        private void Apply(AssetStatusUpdated ev)
        {
            _status = ev.Status;
        }

        private void Apply(AssetLanguageUpdated ev)
        {
            _language = ev.Language;
        }

        private void Apply(AssetMetaDataUpdated ev)
        {
            _metaData = ev.Metadata;
        }

        private void Apply(AssetCreatedByUpdated ev)
        {
            _createdBy = ev.CreatedBy;
        }

        private void Apply(AssetModifiedByUpdated ev)
        {
            _modifiedBy = ev.ModifiedBy;
        }

        private void Apply(AssetMediaAddedUpdated ev)
        {
            MediaList.Add(ev.AddMedia.ToString(),ev.AddMedia.ToString());
        }
        private void Apply(AssetMediaRemovedUpdated ev)
        {
            MediaList.Remove(ev.RemoveMedia.ToString());
        }

        private void Apply(AssetDeleted ev)
        {
            _deleted = ev.Deleted;
        }
    }
}