using System.Collections.Generic;
using Newtonsoft.Json;

namespace Domain.Entities.Asset.SharedMethods
{
    public class ObjectToDictionary
    {
        public Dictionary<string, string> TransformObject(object obj)
        {
            return JsonConvert.DeserializeObject<Dictionary<string, string>>(JsonConvert.SerializeObject(obj));
        }
    }
}