using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetMainTitleUpdated: Event
    {
        public string MainTitle { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetMainTitleUpdated() {}
        
        public AssetMainTitleUpdated(Guid causationId, Guid correlationId, Guid aggregateId, string mainTitle)
            :base(causationId, correlationId, aggregateId)
        {
            MainTitle = mainTitle;
        }
    }
}