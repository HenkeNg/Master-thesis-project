using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetDeleted : Event
    {
        public bool Deleted { get; set; }
     
        [Obsolete("Serialization constructor only", true)]
        public AssetDeleted(){}
        public AssetDeleted(Guid causationId, Guid correlationId, Guid aggregateId, bool value)
            :base(causationId, correlationId, aggregateId)
        {
            Deleted = value;
        }
    }
}