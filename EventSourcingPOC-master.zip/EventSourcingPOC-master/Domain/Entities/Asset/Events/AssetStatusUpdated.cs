using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetStatusUpdated : Event
    {
        public string Status { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetStatusUpdated() {}

        public AssetStatusUpdated(Guid causationId, Guid correlationId, Guid aggregateId, string status) : base(
            causationId, correlationId, aggregateId)
        {
            Status = status;
        }
    }
}