using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetMetaDataUpdated : Event
    {
        public Nullable<Guid> Metadata { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetMetaDataUpdated() {}

        public AssetMetaDataUpdated(Guid causationId, Guid correlationId, Guid aggregateId, Nullable<Guid> metadata)
            : base(causationId, correlationId, aggregateId)
        {
            Metadata = metadata;
        }
    }
}