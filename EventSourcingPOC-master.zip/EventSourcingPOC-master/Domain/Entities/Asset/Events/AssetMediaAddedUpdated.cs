using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetMediaAddedUpdated : Event
    {
        
        public Guid AddMedia { get; set;}
        
        [Obsolete("Serialization constructor only", true)]
        public AssetMediaAddedUpdated(){}

        public AssetMediaAddedUpdated(Guid causationId, Guid correlationId, Guid aggregateId, string media)
            :base(causationId, correlationId, aggregateId)
        {
            AddMedia = new Guid(media);
        }
        
    }
}