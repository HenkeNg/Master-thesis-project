using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetCreatedByUpdated : Event
    {
        public Guid CreatedBy { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetCreatedByUpdated() {}

        public AssetCreatedByUpdated(Guid causationId, Guid correlationId, Guid aggregateId, Guid createdBy)
            :base(causationId, correlationId, aggregateId)
        {
            CreatedBy = createdBy;
        }
    }
}