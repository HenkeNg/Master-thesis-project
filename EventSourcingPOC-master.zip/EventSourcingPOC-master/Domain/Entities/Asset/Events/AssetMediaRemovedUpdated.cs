using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetMediaRemovedUpdated : Event
    {
        
        public Guid RemoveMedia { get; set;}
        
        [Obsolete("Serialization constructor only", true)]
        public AssetMediaRemovedUpdated(){}

        public AssetMediaRemovedUpdated(Guid causationId, Guid correlationId, Guid aggregateId, string media)
            :base(causationId, correlationId, aggregateId)
        {
            RemoveMedia = new Guid(media);
        }
        
    }
}