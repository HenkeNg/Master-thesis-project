using System;
using System.Collections.Generic;

namespace Domain.Entities.Asset.Events
{
    public class AssetMediaListUpdated : Event
    {
        public List<Nullable<Guid>> MediaList { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetMediaListUpdated() {}

        public AssetMediaListUpdated(Guid causationId, Guid correlationId, Guid aggregateId,
            List<Nullable<Guid>> mediaList)
            : base(causationId, correlationId, aggregateId)
        {
            MediaList = mediaList;
        }
    }
}