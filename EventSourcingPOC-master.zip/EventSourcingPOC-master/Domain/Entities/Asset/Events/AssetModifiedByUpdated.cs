using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetModifiedByUpdated : Event
    {
        public Guid ModifiedBy { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetModifiedByUpdated() {}

        public AssetModifiedByUpdated(Guid causationId, Guid correlationId, Guid aggregateId, Guid modifiedBy) : base(
            causationId, correlationId, aggregateId)
        {
            ModifiedBy = modifiedBy;
        }
    }
}