using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetSubtitleUpdated: Event
    {
        public string Subtitle { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetSubtitleUpdated() {}
        
        public AssetSubtitleUpdated(Guid causationId, Guid correlationId, Guid aggregateId, string title)
            :base(causationId, correlationId, aggregateId)
        {
            Subtitle = title;
        }
    }
}