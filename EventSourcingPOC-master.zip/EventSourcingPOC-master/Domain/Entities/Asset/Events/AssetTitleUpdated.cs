﻿using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetTitleUpdated: Event
    {
        public string Title { get; set; }

        [Obsolete("Serialization constructor only", true)]
        public AssetTitleUpdated() {}
        
        public AssetTitleUpdated(Guid causationId, Guid correlationId, Guid aggregateId, string title)
            :base(causationId, correlationId, aggregateId)
        {
            Title = title;
        }
    }
}