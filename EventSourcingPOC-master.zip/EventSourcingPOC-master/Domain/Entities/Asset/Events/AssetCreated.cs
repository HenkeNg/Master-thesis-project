﻿using System;

namespace Domain.Entities.Asset.Events
{
    [Serializable]    
    public class AssetCreated: Event
    {
        [Obsolete("Serialization constructor only", true)]
        public AssetCreated() {}

        public AssetCreated(Guid causationId, Guid correlationId, Guid aggregateId): base(causationId, correlationId, aggregateId)
        {
        }
    }
}