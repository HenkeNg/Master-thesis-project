using System;

namespace Domain.Entities.Asset.Events
{
    public class AssetLanguageUpdated : Event
    {
        public string Language { get; set; }
        
        [Obsolete("Serialization constructor only", true)]
        public AssetLanguageUpdated(){}

        public AssetLanguageUpdated(Guid causationId, Guid correlationId, Guid aggregateId, string language)
            :base(causationId, correlationId, aggregateId)
        {
            Language = language;
        }
    }
}