﻿namespace Domain
{
    public interface ICommand : IMessage
    {
    }
}