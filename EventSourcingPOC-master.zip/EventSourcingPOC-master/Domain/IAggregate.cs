﻿using System;
using System.Collections.Generic;

namespace Domain
{
    public interface IAggregate
    {
        Guid Id { get; set; }
        long Version { get; set; }

        long SnapshotVersion { get; set; }
        bool Deleted { get; set; }
        List<Event> Changes { get; }

        void RebuildState(IEnumerable<Event> events);
    }
}