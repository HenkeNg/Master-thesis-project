﻿using System;
using Domain;

namespace Application
{
    public interface ICommandService
    {
        void ExecuteCommand(ICommand command, Guid? aggregateId = null);
    }
}