﻿namespace Application.Asset.Commands
{
    public class CreateAssetCommandHandler : CommandHandler<CreateAssetCommand, Domain.Entities.Asset.Asset>
    {
        public CreateAssetCommandHandler(IEventStore eventStore, IMessageBus messageBus) : base(eventStore, messageBus)
        {
        }

        protected override void ExecuteAction()
        {
            var asset = new Domain.Entities.Asset.Asset(Command.AssetId);
            asset.UpdateAsset(Command.JsonObject);
            var snapshotEvent = asset.AssetSnapShot();
            PublishChanges(Command, asset, snapshotEvent);
        }
    }
}