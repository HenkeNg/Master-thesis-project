﻿using System;
using Domain;
using Domain.Entities.Asset;

namespace Application.Asset.Commands
{
    [Serializable]
    public class CreateAssetCommand: ICommand
    {        
        public Guid Id { get; set; }
        public Guid CausationId { get; set; }
        public Guid CorrelationId { get; set; }
        public AssetDto AssetDto { get; set; }
        public Guid AssetId { get; set; }

       public object JsonObject { get; set; }

        //Serialization constructor
        public CreateAssetCommand()
        {
        }
        
        public CreateAssetCommand(Guid assetId, object jsonObject)
        {
            Id = Guid.NewGuid();
            CausationId = Guid.Empty;
            CorrelationId = Guid.NewGuid();
           // AssetDto = asset;
           JsonObject = jsonObject;
           AssetId = assetId;
        }
    }
}