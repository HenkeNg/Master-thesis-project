﻿namespace Application.Asset.Commands
{
    public class UpdateAssetCommandHandler : CommandHandler<UpdateAssetCommand, Domain.Entities.Asset.Asset>
    {
        public UpdateAssetCommandHandler(IEventStore eventStore, IMessageBus messageBus) : base(eventStore, messageBus)
        {
        }

        protected override void ExecuteAction()
        {
            Aggregate.UpdateAsset(Command.JsonObject);
            var snapshotEvent = Aggregate.AssetSnapShot();
            PublishChanges(Command, Aggregate, snapshotEvent);
        }
    }
}