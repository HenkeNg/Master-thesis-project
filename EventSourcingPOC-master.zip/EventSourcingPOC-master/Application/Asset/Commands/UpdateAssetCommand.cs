﻿using System;
using Domain;
using Domain.Entities.Asset;

namespace Application.Asset.Commands
{
    public class UpdateAssetCommand: ICommand
    {
        public Guid Id { get; set; }
        public Guid CausationId { get; set; }
        public Guid CorrelationId { get; set; }
        public AssetDto AssetDto { get; set; }
        public Guid AssetId { get; set; }

        public object JsonObject { get; set; }

        public UpdateAssetCommand() {}

        public UpdateAssetCommand(Guid id, object jsonObject)
        {
            Id = Guid.NewGuid();
            CorrelationId = Guid.NewGuid();
            CausationId = Guid.Empty;
            AssetId = id;
            //AssetDto = assetDto;
            JsonObject = jsonObject;
        }        
    }
}