using System;
using System.Collections.Generic;
using System.Linq;
using Domain;
using Domain.Entities.Asset.Events;

namespace Application.Asset.Commands
{
    public class CreateDummyEvent
    {

        public List<Event> createDummy(Guid agg,int size)
        {
            var listOfEvents = new List<Event>();
            for (int i = 0; i < size; i++)
            {
                listOfEvents.Add(new AssetTitleUpdated(agg,agg,agg,"hello"+i));
            }

            return listOfEvents;
        }
        public Event createCreated(Guid agg)
        {
            return new AssetCreated(agg,agg,agg);
        }
    }
}