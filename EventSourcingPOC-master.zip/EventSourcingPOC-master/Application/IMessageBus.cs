﻿using System;
using Domain;

namespace Application
{
    public interface IMessageBus
    {
        void Publish(IMessage message);
        void Subscribe<T>(Action<T> handler) where T : class, IMessage;
    }
}