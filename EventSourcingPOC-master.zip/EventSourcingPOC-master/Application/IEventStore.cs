﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain;
using Domain.Entities.Asset.Events;

namespace Application
 {
     public interface IEventStore
     {
         Task AppendToStreamAsync(Guid aggregateId, long expectedVersion, long expectedSnapshotVersion, IEnumerable<Event> events, Snapshot snapShot);
         Task<EventStoreEvents> ReadAggregateEvents(Guid aggregateId);
         Task<IEnumerable<Event>> ReadAllEvents(long startingPoint, int number);
     }
 }