﻿using System;
using Domain;
 
namespace Application
{
    public abstract class CommandHandler<TC, TA> : ICommandHandler<TC, TA> where TC : class, ICommand where TA : AggregateBase
    {
        protected IMessageBus MessageBus { get; }
        protected IEventStore EventStore { get; }
        
        protected dynamic Aggregate { get; set; }
        protected TC Command { get; set; }
 
        public CommandHandler(IEventStore eventStore, IMessageBus messageBus)
        {
            MessageBus = messageBus;
            EventStore = eventStore;
        }

        protected abstract void ExecuteAction();

        public async void Execute(TC command, Guid? aggregateId = null)
        {
            Command = command;
            if (aggregateId != null)
            {
                Aggregate = Activator.CreateInstance(typeof(TA));
                var response = await EventStore.ReadAggregateEvents((Guid)aggregateId);
                Aggregate.Version = response.Version;
                Aggregate.RebuildState(response.Events);
            }            
            
            ExecuteAction();
        }
 
        protected async void PublishChanges<TL>(TC command, TL aggregate, Snapshot snapShot) where TL: class, IAggregate
        {
            aggregate.Changes.ForEach(a =>
            {
                a.CausationId = command.Id;
                a.CorrelationId = command.CorrelationId;
            });
            try
            {
               await EventStore.AppendToStreamAsync(aggregate.Id, aggregate.Version, aggregate.SnapshotVersion ,aggregate.Changes,snapShot);
                aggregate.Changes.ForEach(a => MessageBus.Publish(a));
            }
            catch (Exception e)
            {
                if (e.ToString().Contains("Expected"))
                {
                    Execute(command);
                }
                else
                {
                    Console.WriteLine(e);
                    throw;
                }
            }
 
        }
    }
}