using System.Collections.Generic;
using Domain;

namespace Application
{
    public class EventStoreEvents
    {
        public long Version { get; }
        public IEnumerable<Event> Events { get; }

        public EventStoreEvents(long version, IEnumerable<Event> events)
        {
            Version = version;
            Events = events;
        }
    }
}