﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure;

namespace ReadModelUpdateRunner
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var eventStore = new Infrastructure.EventStore();
            var assetRepository = new AssetRepository();

            var eventHandlers = new Dictionary<Type, object>();
            var handlerTypes = new List<Type>();

            var handlersAssembly = AppDomain.CurrentDomain.GetAssemblies()
                .FirstOrDefault(a => a.FullName.Contains("ReadModel,"));
            if (handlersAssembly == null)
            {
                throw new Exception("Missing command handlers assembly");
            }

            foreach (var type in handlersAssembly.GetTypes())
            {
                if (type.AssignableFromGenericAncestor(typeof(ReadModel.EventHandler<>)) && !type.IsAbstract)
                {
                    handlerTypes.Add(type);
                }
            }

            foreach (var handlerType in handlerTypes)
            {
                eventHandlers[handlerType.GetAncestorGenericArguments()[0]] =
                    Activator.CreateInstance(handlerType, assetRepository);
            }

            Console.WriteLine("ReadmodelUpdateRunner running ...");

            while (true)
            {
                var start = assetRepository.GetEventsCount();
                var events = await eventStore.ReadAllEvents(start, 10);
                foreach (var @event in events)
                {
                    if (!eventHandlers.ContainsKey(@event.GetType())) continue;
                    dynamic handler = eventHandlers[@event.GetType()];
                    handler.Handle((dynamic) @event);
                }
            }
        }
    }
}