﻿using System;
using System.Net;
using System.Net.Http;
using System.Text;
using Application;
using Application.Asset.Commands;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ReadModel.Asset;

namespace RESTAPI.Controllers
{
    [Route("api/[controller]/{id?}")]
    [ApiController]
    public class AssetController : ControllerBase
    {
        private readonly ICommandService _commandService;
        private readonly IAssetRepository _assetRepository;

        public AssetController(ICommandService commandService, IAssetRepository assetRepository)
        {
            _commandService = commandService;
            _assetRepository = assetRepository;
        }

        // POST api/asset
        [HttpPost]
        public HttpResponseMessage Post(object input)
        {
            var assetId = Guid.NewGuid();

            _commandService.ExecuteCommand(new CreateAssetCommand(assetId, input));
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        // PUT api/asset/{id}
        [HttpPut]
        public HttpResponseMessage Put([FromRoute] Guid id, object input)
        {
            _commandService.ExecuteCommand(new UpdateAssetCommand(id, input), id);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        // GET api/asset
        [HttpGet]
        public HttpResponseMessage Get()
        {
            var assets = _assetRepository.GetAssets();
            return new HttpResponseMessage
            {
                Content = new StringContent(JsonConvert.SerializeObject(assets), Encoding.UTF8),
                StatusCode = HttpStatusCode.OK
            };
        }
    }
}